// IntroductionVViewController.swift
//  PersonalityQuiz
//
//  Created by Akanksha on 2025-02-24.

import UIKit

class IntroductionViewController: TreeBaseViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Quiz Introduction"
        
    }
    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
            
        }
   
}

