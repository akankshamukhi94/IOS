//  TreeBaseViewController.swift
//  PersonalityTree
//
//  Created by Akanksha on 2025-02-24.
import UIKit

class TreeBaseViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(red: 0.05, green: 0.25, blue: 0.05, alpha: 1.0)
    }
    
}
