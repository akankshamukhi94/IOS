//  ResultsHistoryViewController.swift
//  PersonalityQuiz
//
//  Created by Akanksha on 2025-02-24.

import UIKit

class ResultsHistoryViewController: TreeBaseViewController {

    @IBOutlet weak var historyLabel: UILabel!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "History"
        refreshHistoryView()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshHistoryView() // Update display when tab is revisited
    }

    private func refreshHistoryView() {
        let entries = HistoryManager.instance.retrieveAllEntries()
        if entries.isEmpty {
            historyLabel.text = "No past entries available."
        } else {
            historyLabel.text = entries.joined(separator: "\n---\n") // Different separator
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
