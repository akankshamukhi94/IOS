//  ResultsViewController.swift
//  PersonalityTree
//
//  Created by Akanksha on 2025-02-24.

import UIKit

class ResultsViewController: TreeBaseViewController {
    @IBOutlet weak var resultLabel: UILabel!
    let answers: [Answer]

    init?(coder: NSCoder, answers: [Answer]) {
        self.answers = answers
        super.init(coder: coder)
    }

    required init?(coder: NSCoder) {
        self.answers = []
        super.init(coder: coder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
       
        determinePersonalityOutcome()
    }
    @IBAction func poptointro(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    
    func determinePersonalityOutcome() {
        // Check for empty answers
        if answers.isEmpty {
            resultLabel.text = "No answers provided yet."
            return
        }
        
        // Tally occurrences of each personality type
        let typeCounts = answers.reduce(into: [PersonalityType: Int]()) { tally, answer in
            tally[answer.type, default: 0] += 1
        }
        
        // Order by count (descending) and select the top one
        let orderedCounts = typeCounts.sorted { $0.value > $1.value }
        
        guard let dominantType = orderedCounts.first?.key else {
            resultLabel.text = "Couldn’t determine a personality type."
            return
        }
        
        // Check for ties at the top frequency
        let topCount = orderedCounts.first!.value
        let tiedOutcomes = orderedCounts.filter { $0.value == topCount }.map { $0.key }
        
        // Show result using the dominant type
        resultLabel.text = "Your personality is \(dominantType.rawValue)!\n\(dominantType.definition)"
        HistoryManager.instance.saveEntry("Personality: \(dominantType.rawValue)")
    }
}
