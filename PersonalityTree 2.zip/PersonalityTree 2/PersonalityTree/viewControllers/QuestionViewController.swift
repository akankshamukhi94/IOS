//  QuestionViewController.swift
//  PersonalityQuiz
//
//  Created by Akanksha on 2025-02-24.

import UIKit

class QuestionViewController: TreeBaseViewController {
    // Outlets unchanged
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var singleStackView: UIStackView!
    @IBOutlet weak var singleButton1: UIButton!
    @IBOutlet weak var singleButton2: UIButton!
    @IBOutlet weak var singleButton3: UIButton!
    @IBOutlet weak var singleButton4: UIButton!
    @IBOutlet weak var multipleStackView: UIStackView!
    @IBOutlet weak var multiLabel1: UILabel!
    @IBOutlet weak var multiLabel2: UILabel!
    @IBOutlet weak var multiLabel3: UILabel!
    @IBOutlet weak var multiLabel4: UILabel!
    @IBOutlet weak var multiSwitch1: UISwitch!
    @IBOutlet weak var multiSwitch2: UISwitch!
    @IBOutlet weak var multiSwitch3: UISwitch!
    @IBOutlet weak var multiSwitch4: UISwitch!
    @IBOutlet weak var rangedStackView: UIStackView!
    @IBOutlet weak var rangedSlider: UISlider!
    @IBOutlet weak var rangedLabel1: UILabel!
    @IBOutlet weak var rangedLabel2: UILabel!
    @IBOutlet weak var submitMultipleButton: UIButton!
    @IBOutlet weak var submitRangedButton: UIButton!
    @IBOutlet weak var progress: UIProgressView!
    
    var questions: [Question] = [
        // Single-choice questions with tree mapping
        Question(text: "Which drink do you enjoy most?",
                 type: .single,
                 answers: [
                    Answer(text: "Water", type: .Oak),
                    Answer(text: "Juice", type: .Pine),
                    Answer(text: "Soda", type: .Maple),
                    Answer(text: "Milk", type: .Willow)
                 ]),
        Question(text: "What’s your favorite time of day?",
                 type: .single,
                 answers: [
                    Answer(text: "Morning", type: .Oak),
                    Answer(text: "Noon", type: .Pine),
                    Answer(text: "Evening", type: .Maple),
                    Answer(text: "Night", type: .Willow)
                 ]),
        Question(text: "Where would you rather relax?",
                 type: .single,
                 answers: [
                    Answer(text: "Forest", type: .Oak),
                    Answer(text: "Mountain", type: .Pine),
                    Answer(text: "Park", type: .Maple),
                    Answer(text: "Riverbank", type: .Willow)
                 ]),
        
        // Multiple-choice questions with tree mapping
        Question(text: "Which snacks do you like?",
                 type: .multiple,
                 answers: [
                    Answer(text: "Nuts", type: .Oak),
                    Answer(text: "Berries", type: .Pine),
                    Answer(text: "Candy", type: .Maple),
                    Answer(text: "Popcorn", type: .Willow)
                 ]),
        Question(text: "What activities do you enjoy?",
                 type: .multiple,
                 answers: [
                    Answer(text: "Hiking", type: .Oak),
                    Answer(text: "Climbing", type: .Pine),
                    Answer(text: "Picnics", type: .Maple),
                    Answer(text: "Reading", type: .Willow)
                 ]),
        Question(text: "Which colors appeal to you?",
                 type: .multiple,
                 answers: [
                    Answer(text: "Brown", type: .Oak),
                    Answer(text: "Green", type: .Pine),
                    Answer(text: "Red", type: .Maple),
                    Answer(text: "Silver", type: .Willow)
                 ]),
        
        // Ranged-choice questions with tree mapping
        Question(text: "How much do you like sunny days?",
                 type: .ranged,
                 answers: [
                    Answer(text: "Not much", type: .Oak),
                    Answer(text: "A little", type: .Pine),
                    Answer(text: "Quite a bit", type: .Maple),
                    Answer(text: "Love them", type: .Willow)
                 ]),
        Question(text: "How tall do you feel?",
                 type: .ranged,
                 answers: [
                    Answer(text: "Short", type: .Oak),
                    Answer(text: "Medium", type: .Pine),
                    Answer(text: "Tall", type: .Maple),
                    Answer(text: "Very tall", type: .Willow)
                 ]),
        Question(text: "How strong do you feel?",
                 type: .ranged,
                 answers: [
                    Answer(text: "Gentle", type: .Oak),
                    Answer(text: "Steady", type: .Pine),
                    Answer(text: "Firm", type: .Maple),
                    Answer(text: "Tough", type: .Willow)
                 ])
    ]
    
    var questionIndex = 0
    var answersChosen: [Answer] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionIndex = 0
        answersChosen = []
        progress.setProgress(0.0, animated: false) // Initialize progress to 0
        updateUI()
    }
    
    func updateUI() {
        singleStackView.isHidden = true
        multipleStackView.isHidden = true
        rangedStackView.isHidden = true
        submitMultipleButton.isHidden = true
        submitRangedButton.isHidden = true
        
        let currentQuestion = questions[questionIndex]
        questionLabel.text = currentQuestion.text
        navigationItem.title = "Question \(questionIndex + 1)"
        
        // Update progress: completed questions / total questions
        let progressValue = Float(questionIndex) / Float(questions.count)
        progress.setProgress(progressValue, animated: true)
        
        switch currentQuestion.type {
        case .single:
            updateSingleStack(using: currentQuestion.answers)
        case .multiple:
            updateMultipleStack(using: currentQuestion.answers)
        case .ranged:
            updateRangedStack(using: currentQuestion.answers)
        }
    }
    
    func updateSingleStack(using answers: [Answer]) {
        singleStackView.isHidden = false
        singleButton1.setTitle(answers[0].text, for: .normal)
        singleButton2.setTitle(answers[1].text, for: .normal)
        singleButton3.setTitle(answers[2].text, for: .normal)
        singleButton4.setTitle(answers[3].text, for: .normal)
    }
    
    func updateMultipleStack(using answers: [Answer]) {
        multipleStackView.isHidden = false
        submitMultipleButton.isHidden = false
        submitRangedButton.isHidden = true
        multiLabel1.text = answers[0].text
        multiLabel2.text = answers[1].text
        multiLabel3.text = answers[2].text
        multiLabel4.text = answers[3].text
        multiSwitch1.isOn = false
        multiSwitch2.isOn = false
        multiSwitch3.isOn = false
        multiSwitch4.isOn = false
    }
    
    func updateRangedStack(using answers: [Answer]) {
        rangedStackView.isHidden = false
        submitMultipleButton.isHidden = true
        submitRangedButton.isHidden = false
        rangedLabel1.text = answers.first?.text
        rangedLabel2.text = answers.last?.text
        rangedSlider.setValue(0.5, animated: false)
    }
    
    @IBAction func singleAnswerButtonPressed(_ sender: UIButton) {
        let currentAnswers = questions[questionIndex].answers
        switch sender {
        case singleButton1: answersChosen.append(currentAnswers[0])
        case singleButton2: answersChosen.append(currentAnswers[1])
        case singleButton3: answersChosen.append(currentAnswers[2])
        case singleButton4: answersChosen.append(currentAnswers[3])
        default: break
        }
        nextQuestion()
    }
    
    @IBAction func multipleAnswerButtonPressed() {
        let currentAnswers = questions[questionIndex].answers
        if multiSwitch1.isOn { answersChosen.append(currentAnswers[0]) }
        if multiSwitch2.isOn { answersChosen.append(currentAnswers[1]) }
        if multiSwitch3.isOn { answersChosen.append(currentAnswers[2]) }
        if multiSwitch4.isOn { answersChosen.append(currentAnswers[3]) }
        nextQuestion()
    }
    
    @IBAction func rangedAnswerButtonPressed() {
        let currentAnswers = questions[questionIndex].answers
        let index = Int(round(rangedSlider.value * Float(currentAnswers.count - 1)))
        if index >= 0 && index < currentAnswers.count {
            answersChosen.append(currentAnswers[index])
        }
        nextQuestion()
    }
    
    func nextQuestion() {
        questionIndex += 1
        if questionIndex < questions.count {
            updateUI()
        } else {
            // Set progress to 100% before segue
            progress.setProgress(1.0, animated: true)
            performSegue(withIdentifier: "Results", sender: nil)
        }
    }
    
    @IBSegueAction func showResults(_ coder: NSCoder) -> ResultsViewController? {
        return ResultsViewController(coder: coder, answers: answersChosen)
    }
}
