//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Akanksha on 2025-02-24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

