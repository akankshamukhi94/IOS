struct Question {
    let text: String
    let type: ResponseType
    let answers: [Answer]
}

enum ResponseType {
    case single, multiple, ranged
}

struct Answer {
    let text: String
    let type: PersonalityType
}

enum PersonalityType: String {
    case Oak = "Oak"
    case Pine = "Pine"
    case Maple = "Maple"
    case Willow = "Willow"
    
    var definition: String {
        switch self {
        case .Oak:
            return "You’re the mighty Oak—strong enough to hold a treehouse full of giggling kids!"
        case .Pine:
            return "You’re the towering Pine—always reaching for the sky, probably tickling the clouds!"
        case .Maple:
            return "You’re the sweet Maple—drizzling syrupy kindness wherever you go!"
        case .Willow:
            return "You’re the whimsical Willow—swaying in the breeze like nature’s dance party host!"
        }
    }
}
