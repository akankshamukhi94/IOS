

import Foundation

class HistoryManager {
    static let instance = HistoryManager()
    private var pastEntries: [String] = []
    
    private init() {} // Ensures singleton pattern
    
    func saveEntry(_ entry: String) {
        pastEntries.insert(entry, at: 0) // Adds new entries at the start instead of appending
    }
    
    func retrieveAllEntries() -> [String] {
        return pastEntries.reversed() // Returns entries in reverse order
    }
}
